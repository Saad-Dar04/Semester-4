struct Node
{
	int data;
	Node*next;
};