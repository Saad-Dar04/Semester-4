struct Node
{
	int data;
	Node*leftChild;
	Node*rightChild;
};